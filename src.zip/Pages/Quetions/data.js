const questions = [
  {
    id: 1,
    title: "O'zbekiston qayerda joylashgan?",
    info: "Unicorn vinyl poutine brooklyn, next level direct trade iceland. Shaman copper mug church-key coloring book, whatever poutine normcore fixie cred kickstarter post-ironic street art.",
  },
];

export default questions;

